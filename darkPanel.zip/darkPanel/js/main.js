document.addEventListener('keydown', (e) => {
    if (
        (e.ctrlKey && e.shiftKey && e.key === 'I') ||
        (e.ctrlKey && e.shiftKey && e.key === 'J') ||
        (e.ctrlKey && e.key === 'F12') ||
        e.key === 'F12'
    ) {
        e.preventDefault();
        e.stopImmediatePropagation();
        return false;
    }
});

document.addEventListener('DOMContentLoaded', async function () {
    ('use strict');

    const API_BASE = 'https://darkpanel-backend-swart.vercel.app/api';
    const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

    let csInterface = null;
    try {
        csInterface = new CSInterface();
    } catch (_) {
        console.warn('CSInterface not available. Running in browser preview mode.');
    }

    let isSleeping = false;

    function goSleep() {
        if (isSleeping) return;

        if (infoModal && infoModal.classList.contains('show')) return;

        isSleeping = true;
        document.body.classList.add('dp-sleep');

        document.querySelectorAll('video').forEach((v) => {
            try {
                v.pause();
                v.currentTime = 0;
            } catch (_) {}
        });
    }

    function wakeUp() {
        if (!isSleeping) return;
        isSleeping = false;
        document.body.classList.remove('dp-sleep');
    }

    document.addEventListener('visibilitychange', () => {
        if (document.hidden) goSleep();
        else wakeUp();
    });

    window.addEventListener('blur', goSleep);
    window.addEventListener('focus', wakeUp);

    if (csInterface && typeof csInterface.addEventListener === 'function') {
        try {
            csInterface.addEventListener('com.adobe.csxs.events.ApplicationActivate', () =>
                wakeUp()
            );
            csInterface.addEventListener('com.adobe.csxs.events.ApplicationDeactivate', () =>
                goSleep()
            );
        } catch (e) {
            console.warn('CEP visibility events not available:', e);
        }
    }

    async function getDeviceId() {
        try {
            if (csInterface) {
                const p = csInterface.getSystemPath(SystemPath.USER_DATA);
                if (p) return 'cep_' + String(p);
            }
        } catch (_) {}
        const ua = (navigator.userAgent || '') + (navigator.platform || '');
        const dims = (screen.width || 0) + 'x' + (screen.height || 0);
        return 'web_' + btoa(ua + '|' + dims);
    }
    const deviceId = await getDeviceId();

    async function apiPost(path, body) {
        try {
            const res = await fetch(`${API_BASE}${path}`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(body || {}),
                cache: 'no-store',
            });
            const data = await res.json().catch(() => ({}));
            return { ok: res.ok, data };
        } catch (err) {
            console.error('API error:', err);
            return { ok: false, data: { error: 'network_error' } };
        }
    }

    const startTime = Date.now();
    const uptimeEl = document.getElementById('dp-uptime');

    function updateUptime() {
        if (!uptimeEl) return;
        const diff = Date.now() - startTime;
        const h = String(Math.floor(diff / 3600000)).padStart(2, '0');
        const m = String(Math.floor((diff % 3600000) / 60000)).padStart(2, '0');
        const s = String(Math.floor((diff % 60000) / 1000)).padStart(2, '0');
        uptimeEl.textContent = `${h}:${m}:${s}`;
    }

    setInterval(updateUptime, 1000);
    updateUptime();

    const fpsEl = document.getElementById('dp-fps');
    let lastFrame = performance.now();
    let frames = 0;

    function fpsLoop(now) {
        frames++;
        if (now - lastFrame >= 1000) {
            if (fpsEl) fpsEl.textContent = frames;
            frames = 0;
            lastFrame = now;
        }
        requestAnimationFrame(fpsLoop);
    }
    requestAnimationFrame(fpsLoop);

    const LOCAL_KEY = 'darkpanel_license_key';
    const LICENSE_CACHE = 'darkpanel_license_cache';

    async function checkKey(key) {
        const { data } = await apiPost('/license/check', { key, deviceId });
        if (data?.valid || data?.ok) {
            localStorage.setItem(
                LICENSE_CACHE,
                JSON.stringify({
                    ts: Date.now(),
                    type: data.type || (data.valid ? 'trial' : undefined),
                    expiresAt: data.expiresAt || null,
                })
            );
        }
        return data;
    }

    const platformEl = document.getElementById('dp-platform');
    if (platformEl) {
        platformEl.textContent = navigator.platform || 'Unknown';
    }

    const panelStateEl = document.getElementById('dp-panel-state');
    if (panelStateEl) {
        panelStateEl.textContent = document.hidden ? 'Idle' : 'Active';
    }

    document.addEventListener('visibilitychange', () => {
        if (panelStateEl) {
            panelStateEl.textContent = document.hidden ? 'Idle' : 'Active';
        }
    });

    async function activateKey(key) {
        const { data } = await apiPost('/license/activate', { key, deviceId });
        return data;
    }

    async function validateStoredKey() {
        const key = localStorage.getItem(LOCAL_KEY);
        if (!key) return false;

        if (!navigator.onLine) return true;

        const data = await checkKey(key);
        return !!(data && (data.ok === true || data.valid === true));
    }

    function renderActivationUI() {
        if (!navigator.onLine) {
            showOfflineNeedsNetOverlay();
            return;
        }
        const overlay = document.createElement('div');
        overlay.id = 'dp-activation';
        overlay.style.cssText = `
            position:fixed;inset:0;background:#0f0f10;display:flex;
            align-items:center;justify-content:center;z-index:999999;color:#fff;
            font-family:Inter,system-ui,Arial,sans-serif;
        `;
        overlay.innerHTML = `
            <div style="width:min(420px,90vw);padding:22px 20px;border:1px solid #2a2a2a;
                border-radius:14px;background:linear-gradient(180deg,#141416,#0f0f10)">
                <div style="display:flex;align-items:center;gap:10px;margin-bottom:10px">
                    <div style="width:32px;height:32px;border-radius:8px;background:#3537ff;
                        display:flex;align-items:center;justify-content:center;">🔐</div>
                    <h2 style="margin:0;font-size:18px;font-weight:700">darkPanel Activation</h2>
                </div>
                <p style="margin:6px 0 14px;color:#bdbdbd;font-size:12px">Please enter your key.</p>
                <input id="dp-key" placeholder="XXXX-XXXX-XXXX" spellcheck="false"
                    style="width:100%;padding:10px 12px;border-radius:10px;border:1px solid #2b2b2b;
                    background:#131318;color:#eaeaea;outline:none;font-size:13px">
                <div style="display:flex;gap:10px;margin-top:12px">
                    <button id="dp-activate" style="flex:1;padding:10px 12px;border:0;
                        border-radius:10px;background:#4a6cff;color:#fff;font-weight:600;cursor:pointer">
                        Activate
                    </button>
                    <button id="dp-exit" style="padding:0px 0px;border:0px solid #2b2b2b;
                        border-radius:10px;background:#16161a;color:#ddd;cursor:pointer"></button>
                </div>
                <div id="dp-msg" style="margin-top:10px;color:#9ca3af;font-size:12px;min-height:16px"></div>
            </div>
        `;
        document.body.appendChild(overlay);

        const exitBtn = document.getElementById('dp-exit');
        if (exitBtn) {
            exitBtn.onclick = () => {
                const msgEl = document.getElementById('dp-msg');
                if (msgEl) msgEl.textContent = 'Activation required to continue.';
            };
        }

        const activateBtn = document.getElementById('dp-activate');
        if (activateBtn) {
            activateBtn.onclick = async () => {
                const el = document.getElementById('dp-key');
                const msg = document.getElementById('dp-msg');
                const key = (el?.value || '').trim().toUpperCase();
                if (!msg) return;
                if (!key) {
                    msg.textContent = 'Please paste your key.';
                    return;
                }

                msg.textContent = '🔄 Checking key…';

                const result = await activateKey(key);
                console.log('Activation result:', result);

                if (!result) {
                    msg.textContent = '❌ No response from server.';
                    return;
                }

                if (!result.ok) {
                    const reason = result.error || 'Invalid key.';
                    if (reason === 'bound_to_other_device')
                        msg.textContent = '⚠️ Key already used on another device.';
                    else if (reason === 'trial_expired') msg.textContent = '⏰ Trial expired.';
                    else if (reason === 'not_found') msg.textContent = '❌ Key not found.';
                    else msg.textContent = '❌ ' + reason;
                    return;
                }

                localStorage.setItem(LOCAL_KEY, key);
                msg.textContent = '✅ Activated successfully!';
                await sleep(700);
                overlay.remove();
                startApp();
            };
        }
    }

    function showOfflineRibbon() {
        if (document.getElementById('offline-ribbon')) return;
        const bar = document.createElement('div');
        bar.id = 'offline-ribbon';
        bar.style.cssText = `
            position:fixed;left:12px;right:12px;bottom:10rem;z-index:99999;
            background:#191a1f;border:1px solid #2b2b2b;color:#bbb;
            padding:6px 10px;border-radius:8px;font:12px/1.2 Inter,system-ui;text-align:center;
        `;
        bar.textContent = '📡 Offline mode — some features need internet';
        document.body.appendChild(bar);
        window.addEventListener(
            'online',
            () => {
                bar.remove();
                location.reload();
            },
            { once: true }
        );
    }

    function showOfflineNeedsNetOverlay() {
        const el = document.createElement('div');
        el.style.cssText = `
            position:fixed;inset:0;display:flex;align-items:center;justify-content:center;
            background:#0f0f10;color:#fff;z-index:999999;font-family:Inter,system-ui;flex-direction:column;gap:8px;
        `;
        el.innerHTML = `
            <div style="font-size:40px">📡</div>
            <div style="font-size:16px;font-weight:700">No internet</div>
            <div style="font-size:13px;color:#bdbdbd">Activation requires internet connection</div>
            <button id="retryNet" style="margin-top:10px;padding:8px 14px;border-radius:10px;border:0;background:#4a6cff;color:#fff;font-weight:600">Try again</button>
        `;
        document.body.appendChild(el);
        const go = () => {
            el.remove();
            location.reload();
        };
        const btn = document.getElementById('retryNet');
        if (btn) btn.onclick = go;
        window.addEventListener('online', go, { once: true });
    }

    const hasKey = !!localStorage.getItem(LOCAL_KEY);

    if (!navigator.onLine) {
        if (hasKey) {
            showOfflineRibbon();
            startApp();
        } else {
            showOfflineNeedsNetOverlay();
        }
        return;
    }

    const valid = await validateStoredKey();
    if (!valid) {
        renderActivationUI();
        return;
    }

    let infoAnimating = false;

    const infoModal = document.getElementById('dp-info-modal');
    const infoPanel = infoModal?.querySelector('.info-panel');

    ['mousedown', 'mouseup', 'click', 'pointerdown', 'touchstart'].forEach((evt) => {
        infoModal.addEventListener(
            'pointerdown',
            (e) => {
                if (infoModal.classList.contains('show') && !infoPanel.contains(e.target)) {
                    e.preventDefault();
                    e.stopImmediatePropagation();
                }
            },
            true
        );
    });

    const closeInfoBtn = infoModal?.querySelector('.close-info');
    const btnWrapper = document.querySelector('.btn-wrapper');

    if (infoModal && infoPanel && closeInfoBtn && btnWrapper) {
        btnWrapper.addEventListener('click', openInfoModal);
        closeInfoBtn.addEventListener('click', closeInfoModal);

        infoModal.addEventListener('click', (e) => {
            if (e.target === infoModal) {
                closeInfoModal();
            }
        });

        infoPanel.addEventListener('click', (e) => {
            e.stopPropagation();
        });

        setTimeout(() => {
            if (infoModal && !isSleeping && !infoModal.classList.contains('show')) {
                openInfoModal();
            }
        }, 400);
    }

    function openInfoModal() {
        if (!infoModal || infoAnimating) return;

        isInfoOpen = true;
        infoAnimating = true;
        infoModal.classList.add('show');

        setTimeout(() => {
            fillInfoModal();
            infoAnimating = false;
        }, 300);
    }

    function closeInfoModal() {
        if (!infoModal || infoAnimating) return;

        isInfoOpen = false;
        infoAnimating = true;
        infoModal.classList.remove('show');

        setTimeout(() => {
            infoAnimating = false;
        }, 300);
    }

    async function fillInfoModal() {
        const key = localStorage.getItem(LOCAL_KEY);

        const statusBadge = document.getElementById('modal-status');
        const licenseBadge = document.getElementById('modal-license-status');
        const trialBadge = document.getElementById('modal-trial-days');
        const versionBadge = document.getElementById('modal-version');

        if (!statusBadge || !licenseBadge || !trialBadge || !versionBadge) return;

        licenseBadge.textContent = 'Loading…';
        licenseBadge.className = 'value-badge';
        trialBadge.textContent = '…';
        statusBadge.className = 'value-badge';

        if (navigator.onLine) {
            statusBadge.textContent = 'Online';
            statusBadge.classList.add('online');
        } else {
            statusBadge.textContent = 'Offline';
            statusBadge.classList.add('offline');
        }

        checkKey(key).then((data) => {
            if (!data || !data.ok) {
                licenseBadge.textContent = 'Not Activated';
                licenseBadge.style.color = '#ff0000ff';
                trialBadge.textContent = '–';
                return;
            }

            if (data.type === 'lifetime') {
                licenseBadge.textContent = 'Lifetime';
                licenseBadge.style.color = '#00ff00ff';
                trialBadge.textContent = 'Unlimited';
            }

            if (data.type === 'trial') {
                licenseBadge.textContent = 'Trial';
                licenseBadge.style.color = '#ff8800ff';
                trialBadge.textContent = data.remainingDays ?? '0';
            }
        });

        const version =
            localStorage.getItem('darkpanel_last_applied_version') ||
            localStorage.getItem('darkpanel_installed_version') ||
            '1.0';

        versionBadge.textContent = 'v' + version;
        document.getElementById('modal-env').textContent = csInterface
            ? 'After Effects (CEP)'
            : 'Browser';

        document.getElementById('modal-device').textContent = deviceId.slice(0, 10) + '…';

        document.getElementById('modal-net').textContent = navigator.onLine ? 'Stable' : 'Offline';
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape') closeInfoModal();
        });
    }

    window.addEventListener('online', () => {
        const s = document.getElementById('modal-status');
        if (s) {
            s.textContent = 'Online';
            s.style.color = '#00ff00ff';
        }
    });

    window.addEventListener('offline', () => {
        const s = document.getElementById('modal-status');
        if (s) {
            s.textContent = 'Offline';
            s.style.color = '#ff6f6f';
        }
    });
    let presets = [];
    startApp();

    async function startApp() {
        const GITHUB_RAW = 'https://raw.githubusercontent.com/Cyber05CC/darkpanel/main';
        const UPDATE_URL = API_BASE.replace('/api', '') + '/data/update.json';

        const LS_INSTALLED = 'darkpanel_installed_version';
        const LS_LAST_APPLIED = 'darkpanel_last_applied_version';

        const storedVersion =
            localStorage.getItem(LS_LAST_APPLIED) || localStorage.getItem(LS_INSTALLED);
        const BUNDLE_VERSION = storedVersion || '1.0.0';
        let currentVersion = BUNDLE_VERSION;

        const SUPPORTED_TEXT_FILES = [
            'index.html',
            'css/style.css',
            'js/main.js',
            'CSXS/manifest.xml',
        ];

        let selectedPreset = null;
        const autoPlayCheckbox = document.getElementById('autoPlay');
        const presetList = document.getElementById('presetList');
        const prevPageBtn = document.getElementById('prevPage');
        const nextPageBtn = document.getElementById('nextPage');
        const pageInfo = document.getElementById('pageInfo');
        const allTab = document.getElementById('allTab');
        const favoritesTab = document.getElementById('favoritesTab');
        const refreshBtn = document.getElementById('refresh');
        const applyBtn = document.getElementById('apply');
        const status = document.getElementById('status');
        const textPackBtn = document.getElementById('textPackBtn');
        const effectPackBtn = document.getElementById('effectPackBtn');

        const itemsPerPage = 8;
        let currentPage = 1;
        let totalPages = 1;
        let currentView = 'all';
        let currentPack = localStorage.getItem('currentPack') || 'text';
        let favorites = JSON.parse(localStorage.getItem('favorites') || '[]');

        setupConnectionWatcher();
        await autoUpdateIfNeeded();

        init();
        setupPackDropdown();
        setupTabsUnderline();

        const presetsContainer = document.getElementById('presetList');

        if (presetsContainer) {
            presetsContainer.addEventListener('mousedown', (e) => {
                if (e.target === presetsContainer) {
                    clearPresetSelection();
                }
            });
        }

        function setupConnectionWatcher() {
            function showConnectionAlert(message, type = 'error') {
                const existing = document.querySelector('.net-alert');
                if (existing) existing.remove();

                const alert = document.createElement('div');
                alert.className = `net-alert ${type}`;
                alert.innerHTML = `<span>${type === 'error' ? '📡' : '🌐'} ${message}</span>`;
                document.body.appendChild(alert);

                requestAnimationFrame(() => alert.classList.add('visible'));

                setTimeout(
                    () => {
                        alert.classList.remove('visible');
                        setTimeout(() => alert.remove(), 400);
                    },
                    type === 'error' ? 3500 : 1800
                );
            }

            window.addEventListener('offline', () => {
                showConnectionAlert('Ofline.', 'error');
            });

            window.addEventListener('online', () => {
                showConnectionAlert('Online', 'success');
                setTimeout(() => location.reload(true), 1000);
            });

            if (!navigator.onLine) showConnectionAlert('Ofline.', 'error');
        }

        function isNewerVersion(remote, local) {
            const r = remote.split('.').map(Number);
            const l = local.split('.').map(Number);

            for (let i = 0; i < 3; i++) {
                if ((r[i] || 0) > (l[i] || 0)) return true;
                if ((r[i] || 0) < (l[i] || 0)) return false;
            }
            return false;
        }

        async function autoUpdateIfNeeded() {
            if (!navigator.onLine || isSleeping) {
                console.log('🔄 Offline or sleeping – update skip');
                return;
            }

            try {
                const res = await fetch(UPDATE_URL + '?v=' + Date.now(), {
                    cache: 'no-store',
                });
                if (!res.ok) throw new Error('update.json not found');

                const remote = await res.json();
                if (!remote?.version || !remote.files) return;

                const installed =
                    localStorage.getItem(LS_LAST_APPLIED) ||
                    localStorage.getItem(LS_INSTALLED) ||
                    BUNDLE_VERSION;

                if (!isNewerVersion(remote.version, installed)) {
                    console.log('✅ darkPanel already latest:', installed);
                    currentVersion = installed;
                    return;
                }

                console.log('⬆ darkPanel auto-update', installed, '→', remote.version);

                localStorage.setItem('darkpanel_cache_bust', String(Date.now()));

                let wrote = false;

                if (csInterface) {
                    wrote = await tryWriteToExtension(remote.files);
                }

                if (wrote) {
                    localStorage.setItem(LS_INSTALLED, remote.version);
                    localStorage.setItem(LS_LAST_APPLIED, remote.version);
                    currentVersion = remote.version;
                    hardReloadExtension();
                    return;
                }

                console.warn('❗ tryWriteToExtension failed or csInterface yok – overlay fallback');

                localStorage.setItem(LS_LAST_APPLIED, remote.version);
                currentVersion = remote.version;
                hardReloadUI(remote.version);
            } catch (e) {
                console.warn('❌ autoUpdateIfNeeded error:', e);
            }
        }

        async function tryWriteToExtension(files) {
            if (!csInterface) return false;
            const extRoot = csInterface.getSystemPath(SystemPath.EXTENSION);

            const ensureFoldersScript = (fullPath) => `
                (function() {
                    function ensureFolder(path) {
                        var parts = path.split(/[\\\\\\/]/);
                        var acc = parts.shift();
                        while (parts.length) {
                            acc += "/" + parts.shift();
                            var f = new Folder(acc);
                            if (!f.exists) { try { f.create(); } catch(e) { return "ERR:" + e; } }
                        }
                        return "OK";
                    }
                    return ensureFolder("${fullPath.replace(/"/g, '\\"')}");
                })();
            `;

            for (const [rel, info] of Object.entries(files || {})) {
                if (!SUPPORTED_TEXT_FILES.includes(rel)) continue;
                const url = info.url + '?v=' + Date.now();
                const text = await (await fetch(url, { cache: 'no-store' })).text();

                const dir = rel.split('/').slice(0, -1).join('/');
                if (dir) {
                    const targetDir = extRoot + '/' + dir;
                    const ok = await new Promise((resolve) => {
                        csInterface.evalScript(ensureFoldersScript(targetDir), (res) =>
                            resolve(res === 'OK')
                        );
                    });
                    if (!ok) return false;
                }

                const targetFile = `${extRoot}/${rel}`;
                const wrote = await writeFileInChunks(targetFile, text);
                if (!wrote) return false;
            }
            return true;
        }

        async function writeFileInChunks(targetFile, text) {
            if (!csInterface) return false;
            const chunkSize = 30000;
            const chunks = [];
            for (let i = 0; i < text.length; i += chunkSize) {
                chunks.push(text.substring(i, i + chunkSize));
            }

            let mode = 'w';
            for (const chunk of chunks) {
                const writeChunkScript = `
                    (function() {
                        try {
                            var f = new File("${targetFile.replace(/"/g, '\\"')}");
                            f.encoding = "UTF-8";
                            f.open("${mode}");
                            f.write(${JSON.stringify(chunk)});
                            f.close();
                            return "OK";
                        } catch(e) { return "ERR:" + e; }
                    })();
                `;
                const result = await new Promise((resolve) => {
                    csInterface.evalScript(writeChunkScript, (res) => resolve(res === 'OK'));
                });
                if (!result) return false;
                mode = 'a';
            }
            return true;
        }

        function hardReloadExtension() {
            sessionStorage.clear();
            const keep = {
                favorites: localStorage.getItem('favorites'),
                currentPack: localStorage.getItem('currentPack'),
                gridCols: localStorage.getItem('gridCols'),
                installed: localStorage.getItem(LS_INSTALLED),
                lastApplied: localStorage.getItem(LS_LAST_APPLIED),
                license: localStorage.getItem(LOCAL_KEY),
            };
            localStorage.clear();
            if (keep.favorites) localStorage.setItem('favorites', keep.favorites);
            if (keep.currentPack) localStorage.setItem('currentPack', keep.currentPack);
            if (keep.gridCols) localStorage.setItem('gridCols', keep.gridCols);
            if (keep.installed) localStorage.setItem(LS_INSTALLED, keep.installed);
            if (keep.lastApplied) localStorage.setItem(LS_LAST_APPLIED, keep.lastApplied);
            if (keep.license) localStorage.setItem(LOCAL_KEY, keep.license);

            if (csInterface) {
                csInterface.evalScript(
                    `
                    (function(){
                        try {
                            var extPath = new File($.fileName).parent.fsName;
                            var indexFile = new File(extPath + "/index.html");
                            if(indexFile.exists){
                                app.scheduleTask('$.evalFile(\\'' + indexFile.fsName + '\\')', 0, false);
                            }
                            return "Panel restarted";
                        } catch(e){ return "Error: " + e; }
                    })();
                `,
                    (res) => console.log('🔁 Reload:', res)
                );
            }
            setTimeout(() => location.reload(true), 800);
        }

        function hardReloadUI(version) {
            setTimeout(() => location.reload(true), 300);
        }

        function init() {
            updatePackUI();
            createPresets();
            setupEventListeners();
            setupGridControl();
            if (status) status.textContent = 'No items selected';
        }

        function updatePackUI() {
            const packBtn = document.querySelector('.pack-btn');
            if (!packBtn) return;

            const labelSpan = packBtn.querySelector('.pack-label');
            if (!labelSpan) return;

            if (currentPack === 'text') {
                labelSpan.textContent = 'Text Pack';
                textPackBtn?.classList.add('active');
                effectPackBtn?.classList.remove('active');
            } else {
                labelSpan.textContent = 'Effect Pack';
                effectPackBtn?.classList.add('active');
                textPackBtn?.classList.remove('active');
            }
        }

        async function createPresets() {
            if (!presetList) return;
            presetList.innerHTML = '';

            let presetIndexes = [];

            try {
                const res = await fetch(`${GITHUB_RAW}/assets/videos/list.json?v=${Date.now()}`);
                if (res.ok) {
                    const data = await res.json();
                    presetIndexes = Array.isArray(data[currentPack])
                        ? data[currentPack].slice().sort((a, b) => a - b)
                        : [];
                }
            } catch (e) {
                console.warn('list.json load failed:', e);
            }

            const packType = currentPack === 'text' ? 'Text' : 'Effect';

            let uiCounter = 1;

            presetIndexes.forEach((realNum) => {
                const preset = document.createElement('div');
                preset.className = 'preset';

                preset.dataset.file = `${currentPack}_${realNum}.ffx`;

                const imgSrc = `${GITHUB_RAW}/assets/videos/${currentPack}_${realNum}.webp`;

                preset.innerHTML = `
            <div class="preset-thumb">
                <img
                    src="${imgSrc}"
                    class="preset-img"
                    loading="lazy"
                    decoding="async"
                />
                <input
                    type="checkbox"
                    class="favorite-check"
                    data-file="${currentPack}_${realNum}.ffx"
                >
            </div>
            <div class="preset-name">${packType} ${uiCounter}</div>
        `;

                presetList.appendChild(preset);
                uiCounter++;
            });

            presets = document.querySelectorAll('.preset');

            initializeFavorites();
            setupPresetSelection();
            showPage(1);
        }

        function initializeFavorites() {
            presets.forEach((preset) => {
                const file = preset.dataset.file;
                const checkbox = preset.querySelector('.favorite-check');
                if (!checkbox) return;
                checkbox.checked = favorites.includes(file);
                checkbox.addEventListener('change', function () {
                    toggleFavorite(file, this.checked);
                });
            });
        }

        function toggleFavorite(file, isFavorite) {
            if (isFavorite && !favorites.includes(file)) favorites.push(file);
            else if (!isFavorite) favorites = favorites.filter((f) => f !== file);
            localStorage.setItem('favorites', JSON.stringify(favorites));
            if (currentView === 'favorites') showPage(1);
        }

        function filterPresets() {
            return Array.from(presets).filter(
                (preset) => currentView === 'all' || favorites.includes(preset.dataset.file)
            );
        }

        function showPage(page) {
            if (isSleeping) return;

            const filtered = filterPresets();
            currentPage = page;
            totalPages = Math.ceil(filtered.length / itemsPerPage) || 1;

            presets.forEach((p) => (p.style.display = 'none'));

            filtered
                .slice((page - 1) * itemsPerPage, page * itemsPerPage)
                .forEach((p) => (p.style.display = 'block'));

            if (pageInfo) pageInfo.textContent = `Page : ${currentPage}`;
            if (prevPageBtn) prevPageBtn.disabled = currentPage === 1;
            if (nextPageBtn) nextPageBtn.disabled = currentPage === totalPages;
        }

        function setupPresetSelection() {
            const presetsContainer = document.getElementById('presetList');

            if (presetsContainer) {
                presetsContainer.addEventListener('mousedown', (e) => {
                    if (e.target === presetsContainer) {
                        clearPresetSelection();
                    }
                });
            }

            presets.forEach((preset) => {
                preset.addEventListener('click', (e) => {
                    if (e.target.classList.contains('favorite-check')) return;

                    presets.forEach((p) => p.classList.remove('selected'));
                    preset.classList.add('selected');
                    selectedPreset = preset.dataset.file;

                    if (status) {
                        status.textContent = `Selected: ${
                            preset.querySelector('.preset-name').textContent
                        }`;
                    }
                });
            });
        }

        function clearPresetSelection() {
            presets.forEach((p) => p.classList.remove('selected'));
            selectedPreset = null;
            if (status) status.textContent = 'No items selected';
        }

        function setupGridControl() {
            const gridButtons = document.querySelectorAll('.grid-btn');
            const presetsContainer = document.querySelector('.presets');

            if (!presetsContainer || gridButtons.length === 0) return;

            let userSelectedCols = parseInt(localStorage.getItem('gridCols') || '2', 10);

            function applyGrid(cols, fromUser = false) {
                presetsContainer.style.gridTemplateColumns = `repeat(${cols}, 1fr)`;

                if (fromUser) {
                    userSelectedCols = cols;
                    localStorage.setItem('gridCols', String(cols));
                }

                gridButtons.forEach((btn) =>
                    btn.classList.toggle('active', parseInt(btn.dataset.cols) === cols)
                );
            }

            gridButtons.forEach((btn) => {
                btn.addEventListener('click', () => {
                    const cols = parseInt(btn.dataset.cols, 10);
                    applyGrid(cols, true);
                });
            });

            function autoDetectGrid() {
                const width = window.innerWidth;

                if (width <= 420) {
                    applyGrid(1);
                } else if (width <= 640) {
                    applyGrid(2);
                } else if (width <= 720) {
                    applyGrid(3);
                } else {
                    applyGrid(userSelectedCols);
                }
            }

            autoDetectGrid();
            window.addEventListener('resize', autoDetectGrid);
        }

        async function applyPreset() {
            if (!selectedPreset) {
                return;
            }

            const remotePresetUrl = `${GITHUB_RAW}/presets/${selectedPreset}`;
            try {
                const res = await fetch(remotePresetUrl, { cache: 'no-store' });
                if (!res.ok) throw new Error('Preset not found');
                const blob = await res.blob();
                const base64 = await blobToBase64(blob);

                const chunkSize = 20000;
                const chunks = [];
                for (let i = 0; i < base64.length; i += chunkSize) {
                    chunks.push(base64.slice(i, i + chunkSize));
                }

                const openScript = `
                    (function() {
                        try {
                            var presetPath = Folder.temp.fsName + "/darkpanel_temp.ffx";
                            var f = new File(presetPath);
                            f.encoding = "BINARY";
                            if (!f.open("w")) return "Error: Cannot open file for writing";
                            f.close();
                            return presetPath;
                        } catch(e) { return "Error: " + e; }
                    })();
                `;
                const openResult = await new Promise((resolve) =>
                    csInterface
                        ? csInterface.evalScript(openScript, resolve)
                        : resolve('Error: CSInterface not available')
                );
                if (typeof openResult !== 'string' || openResult.indexOf('Error:') === 0) {
                    return;
                }
                const presetPath = openResult;
                const escapedPresetPath = presetPath.replace(/\\/g, '\\\\').replace(/"/g, '\\"');

                for (const chunk of chunks) {
                    const appendScript = `
                        (function() {
                            function b64decode(b64) {
                                var chars="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
                                var out="", buffer=0, bits=0, c;
                                for (var i=0;i<b64.length;i++){
                                    c=b64.charAt(i);
                                    if(c==='=')break;
                                    var idx=chars.indexOf(c);
                                    if(idx===-1)continue;
                                    buffer=(buffer<<6)|idx; bits+=6;
                                    if(bits>=8){bits-=8;out+=String.fromCharCode((buffer>>bits)&0xFF);}
                                }
                                return out;
                            }
                            try {
                                var f = new File("${escapedPresetPath}");
                                f.encoding = "BINARY";
                                if (!f.open("a")) return "Error: Cannot open file for append";
                                var bin = b64decode("${chunk}");
                                f.write(bin);
                                f.close();
                                return "OK";
                            } catch(e) { return "Error: " + e; }
                        })();
                    `;
                    const appendResult = await new Promise((resolve) =>
                        csInterface
                            ? csInterface.evalScript(appendScript, resolve)
                            : resolve('Error: CSInterface not available')
                    );
                    if (appendResult !== 'OK') {
                        return;
                    }
                }

                const applyScript = `
                    (function() {
                        try {
                            var f = new File("${escapedPresetPath}");
                            if (!f.exists) return "Error: File not found";
                            var activeItem = app.project.activeItem;
                            if (!activeItem || !(activeItem instanceof CompItem)) return "Error: No active composition";
                            var selectedLayers = activeItem.selectedLayers;
                            if (selectedLayers.length === 0) return "Error: Please select at least one layer";
                            var successCount = 0;
                            for (var i = 0; i < selectedLayers.length; i++) {
                                selectedLayers[i].applyPreset(f);
                                successCount++;
                            }
                            try { f.remove(); } catch(_) {}
                            return "Success:" + successCount;
                        } catch(err) { return "Error: " + err.toString(); }
                    })();
                `;
                if (!csInterface) {
                    return;
                }
                csInterface.evalScript(applyScript, (result) => {
                    if (result && result.indexOf('Success:') === 0) {
                        const lastAction = document.getElementById('dp-last-action');
                        const lastTime = document.getElementById('dp-last-time');

                        if (lastAction && lastTime) {
                            lastAction.textContent = 'Preset applied';

                            const now = new Date();
                            const h = String(now.getHours()).padStart(2, '0');
                            const m = String(now.getMinutes()).padStart(2, '0');

                            lastTime.textContent = `${h}:${m}`;
                        }

                        showApplyToast();
                    }
                });
            } catch (err) {}
        }

        function blobToBase64(blob) {
            return new Promise((resolve, reject) => {
                const reader = new FileReader();
                reader.onload = () => resolve(String(reader.result).split(',')[1]);
                reader.onerror = reject;
                reader.readAsDataURL(blob);
            });
        }

        function showApplyToast(msg = 'DONE') {
            const old = document.querySelector('.apply-toast');
            if (old) old.remove();

            const toast = document.createElement('div');
            toast.className = 'apply-toast';
            toast.textContent = msg;

            document.body.appendChild(toast);

            setTimeout(() => {
                toast.classList.add('hide');
                setTimeout(() => toast.remove(), 500);
            }, 1200);
        }

        function setupEventListeners() {
            if (autoPlayCheckbox) {
                autoPlayCheckbox.addEventListener('change', () => {
                    if (autoPlayCheckbox.checked) {
                        document.body.classList.add('autoplay-on');
                    } else {
                        document.body.classList.remove('autoplay-on');
                    }
                });
            }

            prevPageBtn?.addEventListener(
                'click',
                () => currentPage > 1 && showPage(currentPage - 1)
            );
            nextPageBtn?.addEventListener(
                'click',
                () => currentPage < totalPages && showPage(currentPage + 1)
            );
            refreshBtn?.addEventListener('click', () => {
                selectedPreset = null;
                presets.forEach((p) => p.classList.remove('selected'));
                if (status) status.textContent = 'No items selected';
                showPage(1);
            });
            applyBtn?.addEventListener('click', applyPreset);
            allTab?.addEventListener('click', () => switchTab('all'));
            favoritesTab?.addEventListener('click', () => switchTab('favorites'));
            textPackBtn?.addEventListener('click', (e) => {
                e.preventDefault();
                switchPack('text');
            });
            effectPackBtn?.addEventListener('click', (e) => {
                e.preventDefault();
                switchPack('effect');
            });

            const copyBtn = document.getElementById('copyDeviceBtn');

            if (copyBtn) {
                copyBtn.addEventListener('click', async () => {
                    try {
                        await navigator.clipboard.writeText(deviceId);

                        copyBtn.textContent = 'Copied!';
                        copyBtn.classList.add('copied');

                        setTimeout(() => {
                            copyBtn.textContent = 'Copy device ID';
                            copyBtn.classList.remove('copied');
                        }, 1200);
                    } catch (e) {
                        console.warn('Clipboard failed, fallback');

                        const ta = document.createElement('textarea');
                        ta.value = deviceId;
                        document.body.appendChild(ta);
                        ta.select();
                        document.execCommand('copy');
                        ta.remove();

                        copyBtn.textContent = 'Copied!';
                        setTimeout(() => {
                            copyBtn.textContent = 'Copy device ID';
                        }, 1200);
                    }
                });
            }

            const checkUpdateBtn = document.getElementById('checkUpdateBtn');

            if (checkUpdateBtn) {
                checkUpdateBtn.addEventListener('click', async () => {
                    if (!navigator.onLine) {
                        showMiniToast('No internet connection');
                        return;
                    }

                    checkUpdateBtn.textContent = 'Checking…';
                    checkUpdateBtn.disabled = true;

                    try {
                        const UPDATE_URL = API_BASE.replace('/api', '') + '/data/update.json';
                        const res = await fetch(UPDATE_URL + '?v=' + Date.now(), {
                            cache: 'no-store',
                        });

                        if (!res.ok) throw new Error('update.json not found');

                        const remote = await res.json();

                        const localVersion =
                            localStorage.getItem('darkpanel_last_applied_version') ||
                            localStorage.getItem('darkpanel_installed_version') ||
                            '1.0.0';

                        if (isNewerVersion(remote.version, localVersion)) {
                            showMiniToast(`Updating → v${remote.version}`);
                            await autoUpdateIfNeeded();
                        } else {
                            showMiniToast('You are up to date ✔');
                        }
                    } catch (e) {
                        console.warn(e);
                        showMiniToast('Update check failed');
                    } finally {
                        checkUpdateBtn.textContent = 'Check update';
                        checkUpdateBtn.disabled = false;
                    }
                });
            }
        }

        function showMiniToast(text) {
            const old = document.querySelector('.mini-toast');
            if (old) old.remove();

            const t = document.createElement('div');
            t.className = 'mini-toast';
            t.textContent = text;
            document.body.appendChild(t);

            requestAnimationFrame(() => t.classList.add('show'));

            setTimeout(() => {
                t.classList.remove('show');
                setTimeout(() => t.remove(), 300);
            }, 1600);
        }

        function switchPack(type) {
            if (currentPack === type) return;
            currentPack = type;
            localStorage.setItem('currentPack', type);
            updatePackUI();
            createPresets();
            selectedPreset = null;
            if (status) status.textContent = 'No items selected';
        }

        function switchTab(type) {
            if (currentView === type) return;
            currentView = type;
            allTab?.classList.toggle('active', type === 'all');
            favoritesTab?.classList.toggle('active', type === 'favorites');
            selectedPreset = null;
            if (status) status.textContent = 'No items selected';
            showPage(1);
        }

        function setupTabsUnderline() {
            const tabsContainer = document.querySelector('.tabs');
            const tabs = document.querySelectorAll('.tab');
            const underline = document.querySelector('.underline');

            if (!tabsContainer || !underline || !tabs.length) return;

            function moveUnderline(tab) {
                const r = tab.getBoundingClientRect();
                const pr = tabsContainer.getBoundingClientRect();

                const left = r.left - pr.left;
                const width = r.width;

                document.documentElement.style.setProperty('--underline-left', left + 'px');
                document.documentElement.style.setProperty('--underline-width', width + 'px');
            }

            const activeTab = document.querySelector('.tab.active') || tabs[0];
            moveUnderline(activeTab);

            tabs.forEach((tab) => {
                tab.addEventListener('click', () => {
                    document.querySelector('.tab.active')?.classList.remove('active');
                    tab.classList.add('active');
                    moveUnderline(tab);
                });
            });

            window.addEventListener('resize', () => {
                const active = document.querySelector('.tab.active');
                if (active) moveUnderline(active);
            });
        }
        function setupPackDropdown() {
            const packDropdown = document.querySelector('.pack-dropdown');
            if (!packDropdown) return;

            const packBtn = packDropdown.querySelector('.pack-btn');
            const label = packBtn.querySelector('.pack-label');
            const arrow = packBtn.querySelector('.pack-arrow');
            const dropdown = packDropdown.querySelector('.pack-dropdown-content');

            if (!packBtn || !dropdown) return;

            packBtn.addEventListener('click', (e) => {
                e.stopPropagation();
                dropdown.classList.toggle('show');
                packBtn.classList.toggle('active');
            });

            textPackBtn?.addEventListener('click', (e) => {
                e.preventDefault();
                dropdown.classList.remove('show');
                packBtn.classList.remove('active');
                switchPack('text');
            });

            effectPackBtn?.addEventListener('click', (e) => {
                e.preventDefault();
                dropdown.classList.remove('show');
                packBtn.classList.remove('active');
                switchPack('effect');
            });

            document.addEventListener('click', (e) => {
                if (!packDropdown.contains(e.target)) {
                    dropdown.classList.remove('show');
                    packBtn.classList.remove('active');
                }
            });
        }
        const tabsContainer = document.querySelector('.tabs');
        const tabs = document.querySelectorAll('.tab');
        const underline = document.querySelector('.underline');

        if (tabsContainer && underline && tabs.length > 0) {
            function moveUnderline(el) {
                const rect = el.getBoundingClientRect();
                const parentRect = tabsContainer.getBoundingClientRect();

                const left = rect.left - parentRect.left;
                const width = rect.width;

                tabsContainer.style.setProperty('--underline-left', left + 'px');
                tabsContainer.style.setProperty('--underline-width', width + 'px');
            }

            const active = document.querySelector('.tab.active');
            if (active) moveUnderline(active);

            tabs.forEach((tab) => {
                tab.addEventListener('click', () => {
                    document.querySelector('.tab.active')?.classList.remove('active');
                    tab.classList.add('active');
                    moveUnderline(tab);
                });
            });

            window.addEventListener('resize', () => {
                const activeTab = document.querySelector('.tab.active');
                if (activeTab) moveUnderline(activeTab);
            });
        }
    }
});
